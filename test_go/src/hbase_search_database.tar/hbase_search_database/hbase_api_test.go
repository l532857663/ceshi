package hbase_search_database

import (
	"testing"
	"fmt"
)

func Test_api_test (t *testing.T) {
	fmt.Println("START")

	hbase_api_get_row_key()

	fmt.Println("END")
}

func hbase_api_get_row_key() {
	addr := "http://127.0.0.1:9900"

	res_data_map, ok := Get_row_key_api (addr)
	if !ok {
		return
	}
	fmt.Println("res_data_map:", res_data_map)
}
