/**
 * 文件功能：数据结构map
 */

package hbase_search_database

import (
	//"fmt"
)


