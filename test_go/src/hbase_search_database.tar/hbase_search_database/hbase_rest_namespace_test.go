package hbase_search_database

import (
	"testing"
	"fmt"

	"strings"
)

func Test_rest_namespace (t *testing.T) {
	addr := "http://127.0.0.1:9900"
	hbase_rest := Hbase_rest {
		Method : "GET",
		Url : addr + "/namespaces",
	}

	fmt.Println("namespace url:", hbase_rest.Url)

	res_data := Hbase_resp_namespace{}
	res_str := hbase_rest.Start(&res_data)
	if strings.Compare(res_str, "error") == 0 {
		fmt.Println("namespace database ", res_str)
		return
	}else if strings.Compare(res_str, "empty") == 0 {
		return
	}

	fmt.Println("res_data:", res_data)
}
