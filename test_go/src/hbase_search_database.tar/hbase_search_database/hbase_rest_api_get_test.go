package hbase_search_database

import (
	"testing"
	"fmt"
)

func Test_rest_api_get (t *testing.T) {
	addr := "http://127.0.0.1:9900"
	url_info := map[string]string {
		//必填
		"tablename" : "data_analysis_task",
		"rowkey" : "1545186486",
		//可选
		"namespace" : "",
		"family" : "info",
		//想要column必须写family
		"column" : "title",
	}

	//obj结果 Hbase_resp_row
	res_data_obj, ok := Get_obj_data_api (addr, url_info)
	if !ok {
		return
	}
	fmt.Println("res_data_obj:", res_data_obj)

	//map结果 map[string]map[string]string
	//			  row_key    column  value
	res_data_map, ok := Get_map_data_api (addr, url_info)
	if !ok {
		return
	}
	fmt.Println("res_data_map:", res_data_map)
}
