package hbase_search_database

import (
	"testing"
	"fmt"
)

func Test_rest_api_put (t *testing.T) {
	addr := "http://127.0.0.1:9900"
	url_info := map[string]string {
		//必填
		"tablename" : "data_analysis_task",
		//可选
		"namespace" : "",
	}

	tmp_list := []string {
		"1545029516","1545186215","1545186279","1545186297","1545186330",
		"1545186345","1545186396","1545186409","1545186421","1545186433",
		"1545186444","1545186455","1545186474","1545186486","1545186496",
	}

	put_data := make(map[string]map[string]string)
	tmp_map := map[string]string {
		"info:spider_switch" : "open",
		"spider_method:information" : "spider_ready",
		"spider_method:following" : "spider_ready",
		"spider_method:followers" : "spider_ready",
		"spider_method:likes" : "spider_ready",
		"spider_method:media" : "spider_ready",
		"spider_method:tweets" : "spider_ready",
		"spider_method:tweets_replies" : "spider_ready",
	}
	for _, rowkey := range tmp_list {
		put_data[rowkey] = tmp_map
		//fmt.Println(`delete "data_analysis_task", "` + rowkey + `", "info:email"`)
		//fmt.Println(`delete "data_analysis_task", "` + rowkey + `", "info:password"`)
	}
	fmt.Println(addr, url_info)

	//结果
	ok := Put_map_data_api (addr, url_info, put_data)
	if !ok {
		return
	}
	fmt.Println("put data ok")
}
