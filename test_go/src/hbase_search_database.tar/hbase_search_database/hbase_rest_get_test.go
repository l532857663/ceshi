package hbase_search_database

import (
	"testing"
	"fmt"

	"strings"
)

func Test_rest_get (t *testing.T) {
	url_info := map[string]string {
		//必填
		"tablename" : "data_analysis_task",
		"rowkey" : "1545186486",
		//可选
		"namespace" : "",
		"family" : "info",
		//想要column必须写family
		"column" : "title",
	}

	hbase_rest := Hbase_rest {
		Addr : "http://127.0.0.1:9900",
		Method : "GET",
	}

	res := hbase_rest.Set_url_get (url_info)
	if !res {
		fmt.Println("get url set error!")
		return
	}
	fmt.Println("get url:", hbase_rest.Url)

	res_data := Hbase_resp_row{}
	res_str := hbase_rest.Start(&res_data)
	if strings.Compare(res_str, "error") == 0 {
		fmt.Println("get database ", res_str)
		return
	}else if strings.Compare(res_str, "empty") == 0 {
		return
	}

	fmt.Println("res_data:", res_data)
	res_data.Xml_base642str()
	fmt.Println("res_data str:", res_data)
}
