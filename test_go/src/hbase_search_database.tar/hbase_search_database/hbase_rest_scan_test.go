package hbase_search_database

import (
	"testing"
	"fmt"

	"strings"
)

func Test_rest_scan (t *testing.T) {
	url_info := map[string]string {
		//必填
		"tablename" : "data_analysis_task",
		//可选
		"namespace" : "",
	}

	hbase_rest := Hbase_rest {
		Addr : "http://127.0.0.1:9900",
		Method : "PUT",
		Ask_type : "Scanner",
	}

	res := hbase_rest.Set_url_scan (url_info)
	if !res {
		return
	}
	fmt.Println("scan url:", hbase_rest.Url)

	//scanner 内容
	var column_list []string
	column_list = append(column_list, "info")
	var filter_map_list []map[string]string
	filter_map := Scan_filter_equal("spider_ready")
	filter_map_list = append(filter_map_list, filter_map)
	filter_data := Get_filter_str(filter_map_list, "and")
	fmt.Println("column:", column_list)
	fmt.Println("filter:", filter_data)

	scan_data := map[string]interface{} {
		"batch" : "100",
	//	"start_row" : "1545186297",
	//	"end_row" : "1545186345",
	//	"columns" : column_list,
	//	"filter" : filter_data,
	}

	fmt.Println("scan_data:", scan_data)
	res = hbase_rest.Set_data_scan(scan_data)
	if !res {
		return
	}

	res_data := Hbase_resp_row{}
	var res_str string
	res_str = hbase_rest.Start(&res_data)
	if strings.Compare(res_str[0:4], "http") != 0 {
		fmt.Println("scan data ", res_str)
		return
	}
	fmt.Println("scan data ok:", res_str)

	//obj结果 Hbase_resp_row
	res_data_obj, res := hbase_rest.Get_obj_data_scan(res_str)
	if !res {
		fmt.Println("scanner data")
		return
	}
	fmt.Println("res_data_obj:", res_data_obj)

/*
	map | obj 二选一，都能用
	//map结果 map[string]map[string]string
	//			  row_key    column  value
	res_data_map, res := hbase_rest.Get_map_data_scan(res_str)
	if !res {
		fmt.Println("scanner data")
		return
	}
	fmt.Println("res_data_map:", res_data_map)
*/
}
