/**
 *	文件功能：获取数据通用接口
 * Get_obj_data_api (url_info map[string]string) (res_data *Hbase_resp_row, ok bool)
 * Get_map_data_api (url_info map[string]string) (res_data_map map[string]map[string]string, ok bool)
 */
package hbase_search_database

import (
	"fmt"
	"strings"
)

func Get_obj_data_api (addr string, url_info map[string]string) (res_data Hbase_resp_row, ok bool) {
	hbase_rest := Hbase_rest {
		Addr : addr,
		Method : "GET",
	}

	var res bool
	res = hbase_rest.Set_url_get (url_info)
	if !res {
		fmt.Println("get url set error!")
		ok = false
		return
	}
//	fmt.Println("get url:", hbase_rest.Url)

	res_str := hbase_rest.Start(&res_data)
	if strings.Compare(res_str, "error") == 0 {
		fmt.Println("get database error")
		ok = false
		return
	}else if strings.Compare(res_str, "empty") == 0 {
		fmt.Println("get database empty")
		ok = true
		return
	}

	res_data.Xml_base642str()
//	fmt.Println("res_data_str:", res_data)
	ok = true
	return
}

func Get_map_data_api (addr string, url_info map[string]string) (res_data_map map[string]map[string]string, ok bool) {
	hbase_rest := Hbase_rest {
		Addr : addr,
		Method : "GET",
	}

	var res bool
	res = hbase_rest.Set_url_get (url_info)
	if !res {
		fmt.Println("get url set error!")
		ok = false
		return
	}
//	fmt.Println("get url:", hbase_rest.Url)

	res_data := new(Hbase_resp_row)
	res_str := hbase_rest.Start(res_data)
	if strings.Compare(res_str, "error") == 0 {
		fmt.Println("get database error")
		ok = false
		return
	}else if strings.Compare(res_str, "empty") == 0 {
		fmt.Println("get database empty")
		ok = true
		return
	}

	res_data_map = res_data.Xml_obj2map()
//	fmt.Println("res_data_str:", res_data_map)
	ok = true
	return
}
