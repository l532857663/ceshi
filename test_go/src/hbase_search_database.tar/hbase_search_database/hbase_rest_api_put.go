/**
 *	文件功能：把数据存入hbase数据库
 */

package hbase_search_database

import (
	"fmt"
	"strings"
)

func Put_map_data_api (addr string, url_info map[string]string, put_data_json map[string]map[string]string) (ok bool) {
	hbase_rest := Hbase_rest {
		Addr : addr,
		Method : "PUT",
	}

	var res bool
	res = hbase_rest.Set_url_put (url_info)
	if !res {
		fmt.Println("put url set error!")
		ok = false
		return
	}
//	fmt.Println("put url:", hbase_rest.Url)

	res = hbase_rest.Set_data_put(put_data_json)
	if !res {
		fmt.Println("put data set error!")
		ok = false
		return
	}

	res_data := new (Hbase_resp_row)
	res_str := hbase_rest.Start(res_data)
	if strings.Compare(res_str, "error") == 0 {
		fmt.Println("put database error")
		ok = false
		return
	}

	ok = true
	return
}
