/**
 *	文件功能：用检索条件查hbase，获取scanner扫描器
 */

package hbase_search_database

import (
	"fmt"
	"strings"
	"encoding/xml"
	"encoding/base64"
)

/**
 * 方法功能：设置rest请求的url
 */
func scan_url_info(url_info map[string]string) (url_config *Hbase_url_config) {
	url_map := map[string]string {
		"namespace" : "",
		"tablename" : "",
	}
	for name, _ := range url_map {
		val, the_ok := url_info[name];if !the_ok {
			continue
		}
		url_map[name] = val
	}

	url_config = new(Hbase_url_config)
	url_config.Namespace = url_map["namespace"]
	url_config.Tablename = url_map["tablename"]
	return
}
func (self *Hbase_rest) Set_url_scan (url_info map[string]string) (ok bool) {
	url_config_obj := scan_url_info(url_info)
	self.Url_config = url_config_obj

	url := self.Addr + "/"

	url_config := (self.Url_config).(*Hbase_url_config)

	if strings.Compare(url_config.Tablename, "") == 0 {
		ok = false
		return
	}
	url += url_config.Tablename + "/scanner"

	self.Url = url

	ok = true
	return
}

/**
 * 方法功能：设置rest请求插入数据的xml内容
 */
func scan_data_info(scanner_data map[string]interface{}) (scan_obj *Scanner_config) {
	scan_data := map[string]interface{} {
		"batch" : "",
		"start_row" : "",
		"end_row" : "",
		"start_time" : "",
		"end_time" : "",
		"columns" : make([]string, 0),
		"filter" : "",
	}
	for name, _ := range scan_data {
		value, ok := scanner_data[name]
		if !ok {
			continue
		}
		scan_data[name] = value
	}
	scan_obj = new(Scanner_config)
	scan_obj.Batch = scan_data["batch"].(string)
	scan_obj.StartRow = base64.StdEncoding.EncodeToString ([]byte (scan_data["start_row"].(string)))
	scan_obj.EndRow = base64.StdEncoding.EncodeToString ([]byte (scan_data["end_row"].(string)))
	for _, val := range scan_data["columns"].([]string) {
		column_base64 := base64.StdEncoding.EncodeToString ([]byte (val))
		scan_obj.Column = append(scan_obj.Column, column_base64)
	}
	scan_obj.Filter = scan_data["filter"].(string)

	return
}
func (self *Hbase_rest) Set_data_scan (scanner_data map[string]interface{}) (ok bool) {
	//map to obj to xml
	scan_obj := scan_data_info(scanner_data)

	//fmt.Println("all:", scan_obj)
	scanner_body_byte, err := xml.Marshal(scan_obj)
	if err != nil {
		fmt.Println("xml Marshal error:", err)
		ok = false
		return
	}
	//fmt.Println("all str:", string(scanner_body_byte))
	self.Body = string(scanner_body_byte)

	ok = true
	return
}
