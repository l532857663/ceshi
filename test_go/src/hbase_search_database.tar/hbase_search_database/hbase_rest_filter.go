/**
 * 文件功能:生成scan filter的函数集合，过滤器
 */
package hbase_search_database

/**
 * Scan_filter_equal(value string)
 	ValueFilter ->(按照具体的值来筛选单元格的过滤器)

 * Scan_filter_new_column()
 	FirstKeyOnlyFilter ->(返回的结果集中只包含第一列的数据,它在找到每行的第一列之后会停止扫描)

 * Scan_filter_prefix(value string)
 	PrefixFilter ->(筛选出具有特定前缀的行键的数据)
 */

func Scan_filter_equal (value string) (filter_tmp map[string]string) {
	filter_tmp = map[string]string {
		"Type" : "ValueFilter",
		"Op" : "EQUAL",
		"Comparator_Type" : "BinaryComparator",
		"Comparator_Value" : value,
	}
	return
}

func Scan_filter_new_column () (filter_tmp map[string]string) {
	filter_tmp = map[string]string {
		"Type" : "FirstKeyOnlyFilter",
	}
	return
}

func Scan_filter_prefix(value string) (filter_tmp map[string]string) {
	filter_tmp = map[string]string {
		"Type" : "PrefixFilter",
		"Value" : value,
	}
	return
}
