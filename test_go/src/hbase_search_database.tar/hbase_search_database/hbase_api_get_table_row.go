/**
 *	文件功能：获取数据表的row_key
 */

package hbase_search_database

import (
	"fmt"
	"strings"
//	"encoding/json"
)

func Get_row_key_api (addr string) (row_key map[string]string, ok bool) {
	url_info := map[string]string {
		"tablename" : "search_conditions",
	}

	var test_json_list []map[string]string
	test_json := map[string]string {
		"Type" : "KeyOnlyFilter",
	}
	test_json_list = append(test_json_list, test_json)
	filter_str := Get_filter_str(test_json_list, "and")

	scan_data := map[string]interface{} {
		"batch" : "1000",
		"filter" : filter_str,
	}

	res_task_data, res := Scan_obj_data_api(addr, url_info, scan_data)
	if !res {
		fmt.Println("task scan api error")
		ok = false
		return
	}
	row_key = make(map[string]string)
	for _, obj := range res_task_data.Row {
		tmp_data := strings.Split(obj.Key, ":")[0]
		row_key[tmp_data] = ""
	}

	ok = true
	return
}
