package hbase_search_database

import (
	"testing"
	"fmt"
)

func Test_rest_api_scan (t *testing.T) {
	addr := "http://127.0.0.1:9900"
	url_info := map[string]string {
		//必填
		//"tablename" : "data_analysis_task",
		"tablename" : "spider_user_twitter",
		//可选
		"namespace" : "",
	}

	//scanner 内容
	var column_list []string
	column_list = append(column_list, "info")

	var filter_map_list []map[string]string
	//获取filter
	filter_map := Scan_filter_equal("spider_ready")

	filter_map_list = append(filter_map_list, filter_map)
	filter_data := Get_filter_str(filter_map_list, "and")

	fmt.Println("column:", column_list)
	fmt.Println("filter:", filter_data)

	scan_data := map[string]interface{} {
		"batch" : "100",
	//	"start_row" : "1545186297",
	//	"end_row" : "1545186345",
		"columns" : column_list,
	//	"filter" : filter_data,
	}

	//结果
	res_data_obj, ok := Scan_map_data_api (addr, url_info, scan_data)
	if !ok {
		return
	}
	fmt.Println("res_data_obj:", res_data_obj)
	fmt.Println("res_data_obj len:", len(res_data_obj))

	for key, value := range res_data_obj {
		fmt.Println(key, value)
	}
}
