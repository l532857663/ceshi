package hbase_search_database

import (
	"testing"
	"fmt"

	"strings"
)

func Test_rest_put (t *testing.T) {
	url_info := map[string]string {
		//必填
		"tablename" : "data_analysis_task",
		//可选
		"namespace" : "",
	}

	tmp_list := []string {
		"1545029516","1545186215","1545186279","1545186297","1545186330",
		"1545186345","1545186396","1545186409","1545186421","1545186433",
		"1545186444","1545186455","1545186474","1545186486","1545186496",
	}

	put_data := make(map[string]map[string]string)
	tmp_map := map[string]string {
		"spider_method:information" : "spider_ready",
		"spider_method:following" : "spider_ready",
		"spider_method:followers" : "spider_ready",
		"spider_method:likes" : "spider_ready",
		"spider_method:media" : "spider_ready",
		"spider_method:tweets" : "spider_ready",
		"spider_method:tweets_replies" : "spider_ready",
	}
	for _, rowkey := range tmp_list {
		put_data[rowkey] = tmp_map
	}

	hbase_rest := Hbase_rest {
		Addr : "http://127.0.0.1:9900",
		Method : "PUT",
	}

	res := hbase_rest.Set_url_put (url_info)
	if !res {
		return
	}
	fmt.Println("put url:", hbase_rest.Url)

	fmt.Println("put_data:", put_data)
	res = hbase_rest.Set_data_put(put_data)
	if !res {
		return
	}

	res_data := Hbase_resp_row{}
	var res_str string
	res_str = hbase_rest.Start(&res_data)
	if strings.Compare(res_str, "error") == 0 {
		fmt.Println("put data ", res_str)
		return
	}
	fmt.Println("put data ok")
}
