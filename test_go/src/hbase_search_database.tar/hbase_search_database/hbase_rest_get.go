/**
 *	文件功能：查询hbase数据库
 * 设置Namespace、tablename、row_key、family、column等参数，查询数据
 * tablename、row_key为必须条件，其余选择设置
 */

package hbase_search_database

import (
//	"fmt"
	"strings"
)

/**
 * 方法功能：设置rest请求的url
 */
func get_url_info(url_info map[string]string) (url_config *Hbase_url_config) {
	url_map := map[string]string {
		"namespace" : "",
		"tablename" : "",
		"rowkey" : "",
		"family" : "",
		"column" : "",
	}
	for name, _ := range url_map {
		val, the_ok := url_info[name];if !the_ok {
			continue
		}
		url_map[name] = val
	}

	url_config = new(Hbase_url_config)
	url_config.Namespace = url_map["namespace"]
	url_config.Tablename = url_map["tablename"]
	url_config.Row = url_map["rowkey"]
	url_config.Family = url_map["family"]
	url_config.Column = url_map["column"]
	return
}

func (self *Hbase_rest) Set_url_get (url_info map[string]string) (ok bool) {
	url_config_obj := get_url_info(url_info)
	self.Url_config = url_config_obj

	url := self.Addr + "/"

	url_config := (self.Url_config).(*Hbase_url_config)

	if strings.Compare(url_config.Namespace, "") != 0 {
		url += url_config.Namespace + ":"
	}

	if strings.Compare(url_config.Tablename, "") == 0 {
		ok = false
		return
	}
	url += url_config.Tablename + "/"
	if strings.Compare(url_config.Row, "") == 0 {
		ok = false
		return
	}
	url += url_config.Row + "/"

	if strings.Compare(url_config.Family, "") != 0 {
		url += url_config.Family
		if strings.Compare(url_config.Column, "") != 0 {
			url += ":" + url_config.Column
		}
	}

	self.Url = url

	ok = true
	return
}
