/**
 *	文件功能：获取数据的查询接口
 * Scan_obj_data_api (addr string, url_info map[string]string, scan_info map[string]interface{}) (res_data_obj *Hbase_resp_row, ok bool)
 * Scan_map_data_api (addr string, url_info map[string]string, scan_info map[string]interface{}) (res_data_map map[string]map[string]string, ok bool)
 */
package hbase_search_database

import (
	"fmt"
	"strings"
)

func Scan_obj_data_api (addr string, url_info map[string]string, scan_info map[string]interface{}) (res_data_obj *Hbase_resp_row, ok bool) {
	hbase_rest := Hbase_rest {
		Addr : addr,
		Method : "PUT",
		Ask_type : "Scanner",
	}

	var res bool
	res = hbase_rest.Set_url_scan (url_info)
	if !res {
		ok = false
		return
	}
	//fmt.Println("scan url:", hbase_rest.Url)

	res = hbase_rest.Set_data_scan(scan_info)
	if !res {
		ok = false
		return
	}

	res_data := Hbase_resp_row{}
	var res_str string
	res_str = hbase_rest.Start(&res_data)
	if strings.Compare(res_str[0:4], "http") != 0 {
		fmt.Println("scan data ", res_str)
		ok = false
		return
	}
	//fmt.Println("scan data ok:", res_str)

	//obj结果 Hbase_resp_row
	res_data_obj, res = hbase_rest.Get_obj_data_scan(res_str)
	if !res {
		ok = false
		return
	}

	ok = true
	return
}

func Scan_map_data_api (addr string, url_info map[string]string, scan_info map[string]interface{}) (res_data_map map[string]map[string]string, ok bool) {
	hbase_rest := Hbase_rest {
		Addr : addr,
		Method : "PUT",
		Ask_type : "Scanner",
	}

	var res bool
	res = hbase_rest.Set_url_scan (url_info)
	if !res {
		ok = false
		return
	}
	//fmt.Println("scan url:", hbase_rest.Url)

	res = hbase_rest.Set_data_scan(scan_info)
	if !res {
		ok = false
		return
	}

	res_data := Hbase_resp_row{}
	var res_str string
	res_str = hbase_rest.Start(&res_data)
	if strings.Compare(res_str[0:4], "http") != 0 {
		fmt.Println("scan data ", res_str)
		ok = false
		return
	}
	//fmt.Println("scan data ok:", res_str)

	//map结果 map[string]map[string]string
	res_data_map, res = hbase_rest.Get_map_data_scan(res_str)
	if !res {
		ok = false
		return
	}

	ok = true
	return
}
