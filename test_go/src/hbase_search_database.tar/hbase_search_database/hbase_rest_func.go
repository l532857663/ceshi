/**
 * 文件功能：构造hbase数据的类型转换方法
 
 *	请求方式GET:
	 	self.Set_method_get()
	PUT:
		self.Set_method_put()
	POST:
		self.Set_method_post()
	DELETE:
		self.Set_method_delete()

 *	map数据转化成可以用xml参数:
 	Map2xml (tmp_data map[string]map[string]string) (tmp_row *Row_config)

 *	查询结果的base64转义为string
 	Xml_base642str ()

 *	map结构获取可用的字符串
 	Get_filter_str (tmp_json_list []map[string]string, relation string) (tmp_filter_str string)

 */

package hbase_search_database

import (
	"fmt"

	"encoding/json"
	"encoding/base64"
	"strings"
	"strconv"
)

func Map2xml (tmp_key string, tmp_data map[string]string) (tmp_row *Row_set){
	tmp_row = new (Row_set)
	//设置key
	tmp_row.Key = base64.StdEncoding.EncodeToString ([]byte (tmp_key))
	//设置cell
	for name, value := range tmp_data {
		tmp_cell := new (Cell_set)
		tmp_cell.Column = base64.StdEncoding.EncodeToString ([]byte (name))
		tmp_cell.Value = base64.StdEncoding.EncodeToString ([]byte (value))

		tmp_row.Cell = append (tmp_row.Cell, *tmp_cell)
	}

	return
}

func Json2string (json_obj interface{}) (json_str string) {
	return
}

func (self *Hbase_resp_row) Xml_base642str () {
	for key, row_obj := range self.Row {
		//row_key base64转string
		rowkey_str := ""
		rowkey_byte, err := base64.StdEncoding.DecodeString(row_obj.Key)
		if err != nil {
			fmt.Println("row_key base64 decode failure")
			rowkey_str = row_obj.Key
		}
		rowkey_str = string(rowkey_byte)
//		fmt.Println("Key:",rowkey_str)
		row_obj.Key = rowkey_str

		for k, cell_obj := range row_obj.Cell {
			//row column base64转string
			column_str := ""
			column_byte, err := base64.StdEncoding.DecodeString(cell_obj.Column)
			if err != nil {
				fmt.Println("row column base64 decode failure")
				column_str = cell_obj.Column
			}
			column_str = string(column_byte)
			cell_obj.Column = column_str
			//row value base64转string
			value_str := ""
			value_byte, err := base64.StdEncoding.DecodeString(cell_obj.Value)
			if err != nil {
				fmt.Println("row value base64 decode failure")
				value_str = cell_obj.Value
			}
			value_str = string(value_byte)
			cell_obj.Value = value_str
			//row timestamp_int64
			tmp_timestamp, err := strconv.ParseInt (cell_obj.Timestamp, 10, 64)
			if err != nil {
				fmt.Println("row timestamp to int64 failure")
				tmp_timestamp = int64(0)
			}
			cell_obj.Timestamp_int64 = tmp_timestamp

			row_obj.Cell[k] = cell_obj
		}
		self.Row[key] = row_obj
	}
}

func (self *Hbase_resp_row) Xml_obj2map () (tmp_rows map[string]map[string]string) {
	tmp_rows = make(map[string]map[string]string)
	for _, row_obj := range self.Row {
		//row_key base64转string
		rowkey_str := ""
		rowkey_byte, err := base64.StdEncoding.DecodeString(row_obj.Key)
		if err != nil {
			fmt.Println("row_key base64 decode failure")
			rowkey_str = row_obj.Key
		}
		rowkey_str = string(rowkey_byte)
//		fmt.Println("Key:",rowkey_str)
		tmp_cell := make(map[string]string)
		for _, cell_obj := range row_obj.Cell {
			//row column base64转string
			column_str := ""
			column_byte, err := base64.StdEncoding.DecodeString(cell_obj.Column)
			if err != nil {
				fmt.Println("row column base64 decode failure")
				column_str = cell_obj.Column
			}
			column_str = string(column_byte)
			//row value base64转string
			value_str := ""
			value_byte, err := base64.StdEncoding.DecodeString(cell_obj.Value)
			if err != nil {
				fmt.Println("row value base64 decode failure")
				value_str = cell_obj.Value
			}
			value_str = string(value_byte)

			tmp_cell[column_str] = value_str
		}
		tmp_rows[rowkey_str] = tmp_cell
	}
	return
}

func Get_filter_str (tmp_json_list []map[string]string, relation string) (tmp_filter_str string) {
	filter_tmp := map[string]string {
		"Type" : "",
		"Value" : "",
		"Op" : "",
		"Comparator_Type" : "",
		"Comparator_Value" : "",
	}
	Comparator_class := map[string]string {
		"BinaryComparator" : "base64",
		"SubstringComparator" : "string",
		"RegexStringComparator" : "string",
	}
	relation_list := map[string]string {
		"and" : "MUST_PASS_ALL",
		"or" : "MUST_PASS_ONE",
	}

	//多filter查询
	tmp_filter_list_json := new(Filter_all_json)
	tmp_filter_list_json.Type = "FilterList"
	_, ok := relation_list[relation]
	if !ok {
		tmp_filter_list_json.Op = "MUST_PASS_ALL"
	}else{
		tmp_filter_list_json.Op = relation_list[relation]
	}
	for _, tmp_json := range tmp_json_list {
		for name, _ := range filter_tmp {
			ss, ok := tmp_json[name]
			if !ok {
				continue
			}
			filter_tmp[name] = ss
		}

		//单个构造
		tmp_filter_json := new(Filter_json)
		tmp_filter_json.Type = filter_tmp["Type"]
		tmp_filter_json.Value = base64.StdEncoding.EncodeToString([]byte (filter_tmp["Value"]))
		tmp_filter_json.Op = filter_tmp["Op"]

		tmp_comparator_json := new(Comparator_json)
		tmp_comparator_json.Type = filter_tmp["Comparator_Type"]
		if strings.Compare(Comparator_class[filter_tmp["Comparator_Type"]], "base64") == 0 {
			tmp_comparator_json.Value = base64.StdEncoding.EncodeToString([]byte (filter_tmp["Comparator_Value"]))
		}else if strings.Compare(Comparator_class[filter_tmp["Comparator_Type"]], "string") == 0 {
			tmp_comparator_json.Value = filter_tmp["Comparator_Value"]
		}else{
			tmp_comparator_json = nil
		}

		tmp_filter_json.Comparator = tmp_comparator_json

		tmp_filter_list_json.Filters = append(tmp_filter_list_json.Filters, tmp_filter_json)
	}

	json_byte, err := json.Marshal(tmp_filter_list_json)
	if err != nil {
		return
	}
	tmp_filter_str = string(json_byte)
	if strings.Compare(tmp_filter_str, "{}") == 0 {
		tmp_filter_str = ""
	}

	return

}

func (self *Hbase_rest) Set_method_get () {
	self.Method = "GET"
}
func (self *Hbase_rest) Set_method_put () {
	self.Method = "PUT"
}
func (self *Hbase_rest) Set_method_post () {
	self.Method = "POST"
}
func (self *Hbase_rest) Set_method_delete () {
	self.Method = "DELETE"
}
