/**
 *	文件功能：把数据存入hbase数据库
 */

package hbase_search_database

import (
	"fmt"
	"strings"
	"encoding/xml"
)

/**
 * 方法功能：设置rest请求的url
 */
func put_url_info(url_info map[string]string) (url_config *Hbase_url_config) {
	url_map := map[string]string {
		"namespace" : "",
		"tablename" : "",
	}
	for name, _ := range url_map {
		val, the_ok := url_info[name];if !the_ok {
			continue
		}
		url_map[name] = val
	}

	url_config = new(Hbase_url_config)
	url_config.Namespace = url_map["namespace"]
	url_config.Tablename = url_map["tablename"]
	return
}

func (self *Hbase_rest) Set_url_put (url_info map[string]string) (ok bool) {
	url_config_obj := put_url_info(url_info)
	self.Url_config = url_config_obj

	url := self.Addr + "/"

	url_config := (self.Url_config).(*Hbase_url_config)

	if strings.Compare(url_config.Namespace, "") != 0 {
		url += url_config.Namespace + ":"
	}

	if strings.Compare(url_config.Tablename, "") == 0 {
		ok = false
		return
	}
	url += url_config.Tablename + "/fakerow"

	self.Url = url

	ok = true
	return
}

/**
 * 方法功能：设置rest请求插入数据的xml内容
 */
func (self *Hbase_rest) Set_data_put (data_arr map[string]map[string]string) (ok bool) {
	insert_data := new (Hbase_insert_config)
	for key, data_map := range data_arr {
		tmp_row := Map2xml (key, data_map)
		insert_data.Row = append(insert_data.Row, *tmp_row)
	}
//	fmt.Println("all:", insert_data)
	put_body_byte, err := xml.Marshal(insert_data)
	if err != nil {
		fmt.Println("xml Marshal error:", err)
		ok = false
		return
	}
//	fmt.Println("all str:", string(put_body_byte))
	self.Body = string(put_body_byte)

	ok = true
	return
}
