#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
训练网络，并保存模型，其中LSTM的实现采用Python中的keras库
"""
import pandas as pd 
import numpy as np 
import multiprocessing
import keras

from pyhanlp import *

from gensim.models.word2vec import Word2Vec
from gensim.corpora.dictionary import Dictionary
from keras.preprocessing import sequence

# from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM
from keras.layers.core import Dense, Dropout,Activation
from keras.models import model_from_yaml
np.random.seed(1337)  # For Reproducibility
import sys
sys.setrecursionlimit(1000000)
import yaml

# set parameters:
cpu_count = multiprocessing.cpu_count() # 4
vocab_dim = 512
n_iterations = 1  # ideally more..
n_exposures = 10 # 所有频数超过10的词语
window_size = 7
n_epoch = 4
input_length = 500
maxlen = 500

batch_size = 500


def loadfile():
    base_data_file = open ('./base_dict.txt', 'r')

    return base_data_file


#对句子经行分词，并去掉换行符
def tokenizer(base_data_file):
    ''' Simple Parser converting each document to lower-case, then
        removing the breaks for new lines and finally splitting on the
        whitespace
    '''
    # text = [jieba.lcut(document.replace('\n', '')) for document in text]
    text_all = []
    for text in base_data_file:
        print (text)
        text = base_data_file.readline ()
        print (text)
        # text = jieba.lcut (text.replace ('\n', ''))
        text_tmp = HanLP.segment (text.replace ('\n', ''))
        text = []
        for word in text_tmp:
            word_str = str (word)
            every_arr = word_str.split ("/")[0]
            text.append (every_arr)

        text_all.append (text)

    print (text_all, "heheda")
    return text_all


def create_dictionaries(model=None,
                        combined=None):
    ''' Function does are number of Jobs:
        1- Creates a word to index mapping
        2- Creates a word to vector mapping
        3- Transforms the Training and Testing Dictionaries

    '''
    if (combined is not None) and (model is not None):
        gensim_dict = Dictionary()
        gensim_dict.doc2bow(model.wv.vocab.keys(),
                            allow_update=True)
        #  freqxiao10->0 所以k+1
        w2indx = {v: k+1 for k, v in gensim_dict.items()}#所有频数超过10的词语的索引,(k->v)=>(v->k)
        w2vec = {word: model[word] for word in w2indx.keys()}#所有频数超过10的词语的词向量, (word->model(word))

        def parse_dataset(combined): # 闭包-->临时使用
            ''' Words become integers
            '''
            data=[]
            for sentence in combined:
                new_txt = []
                for word in sentence:
                    try:
                        new_txt.append(w2indx[word])
                    except:
                        new_txt.append(0) # freqxiao10->0
                data.append(new_txt)
            return data # word=>index
        combined=parse_dataset(combined)
        combined= sequence.pad_sequences(combined, maxlen=maxlen)#每个句子所含词语对应的索引，所以句子中含有频数小于10的词语，索引为0
        return w2indx, w2vec,combined
    else:
        print ('No data provided...')


#创建词语字典，并返回每个词语的索引，词向量，以及每个句子所对应的词语索引
def word2vec_train(combined):

    model = Word2Vec(size=vocab_dim,
                     min_count=n_exposures,
                     window=window_size,
                     workers=cpu_count,
                     iter=n_iterations)
    model.build_vocab(combined) # input: list
    # model.train(combined)
    model.train(combined, total_examples=model.corpus_count, epochs=model.iter)
    # model.save('../lstm_data_test/Word2vec_model.pkl')
    model.save('./Word2vec_model.pkl')
    index_dict, word_vectors,combined = create_dictionaries(model=model,combined=combined)
    return   index_dict, word_vectors,combined


if __name__ == "__main__":
    #训练模型，并保存
    print ('Loading Data...')
    base_data_file=loadfile()
    print ('Tokenising...')
    combined = tokenizer(base_data_file)
    print ('Training a Word2vec model...')
    index_dict, word_vectors,combined=word2vec_train(combined)
    # print (index_dict, word_vectors, combined)

    # 测试index数组
    test_string = "这是我看过文字写得很糟糕的书，因为买了，还是耐着性子看完了，但是总体来说不好，文字、内容、结构都不好"
    # test_string = "你好"
    # test_words = jieba.lcut (test_string)

    text_words = []
    test_words_tmp = HanLP.segment (test_string)
    for word in test_words_tmp:
        word_str = str (word)
        every_arr = word_str.split ("/")[0]
        text_words.append (every_arr)

    print (text_words)
    dict_model = Word2Vec.load ('./Word2vec_model.pkl')
    index, _, combined = create_dictionaries (dict_model, text_words)
    print (len (index))
    print (combined)
