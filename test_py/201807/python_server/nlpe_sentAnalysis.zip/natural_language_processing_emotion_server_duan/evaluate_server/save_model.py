#!/usr/bin/env python3
#-*- coding:utf-8 -*-

import sys
import numpy as np
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, LSTM
from keras.layers.embeddings import Embedding
from keras.preprocessing.text import Tokenizer

from sklearn.model_selection import train_test_split
from gensim.models.word2vec import Word2Vec

from .save_dict import create_dictionaries

class SaveModel():
    def __init__ (self, savepath="model_wt1.h5", max_words=500, batch_size=500, epochs=5, test_split=0.2):
        self.Max_words = max_words
        self.Batch_size = batch_size
        self.Epochs = epochs
        self.Test_split = test_split
        self.Savepath = savepath

    def getArgv(self, x, y, tag_dict_len):
        self.getData(x, y, tag_dict_len)
        return self.Argv_arr

    def getData(self, x, y, tag_dict_len):
        #(x_train_source, y_train_source), (x_test_source, y_test_source) = self.loadData(x, y)

        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1)
        print ("x hehe:", x_train)
        print ("y hehe:", y_train)

        y_train = keras.utils.to_categorical(y_train, num_classes=3)
        y_test = keras.utils.to_categorical(y_test, num_classes=3)

        # x_train, y_train= x[:idx], y[:idx]
        # x_test, y_test= x[idx:], y[idx:]

        num_classes = tag_dict_len + 1

        self.Argv_arr = {"num_classes":num_classes,
                "x_train":x_train,
                "y_train":y_train,
                "x_test":x_test,
                "y_test":y_test}

    def loadData (self, xs, ys, **kwargs):
        #测试数据比例
        test_split = self.Test_split
        xs = np.array(xs)
        labels = np.array(ys)
        #数据量对比
        if not len(xs) == len(labels):
            print("数据错误:",len(xs), len(labels))

        #乱序数据内容
        indices = np.arange(len(xs))
        print("数据量：",len(xs),len(labels),len(indices))
        np.random.shuffle(indices)
        xs = xs[indices]
        if len(indices) < len(labels):
            print("数据错误：",labels, len(labels))
        labels = labels[indices]

        idx = int(len(xs) * (1 - test_split))
        x_train, y_train = xs[:idx], labels[:idx]
        x_test, y_test = xs[idx:], labels[idx:]

        return (x_train, y_train), (x_test, y_test)

    def saveModel (self):
        #参数设定
        argv_arr = self.Argv_arr
        num_classes = argv_arr["num_classes"]
        x_train = argv_arr["x_train"]
        y_train = argv_arr["y_train"]
        x_test = argv_arr["x_test"]
        y_test = argv_arr["y_test"]

        print ('Get index len')
        dict_model = Word2Vec.load ('./evaluate_server/Word2vec_model.pkl')
        dict_index, word_vectors, _ = create_dictionaries (dict_model, ['test'])
        print ('dict_index len: ', len (dict_index) + 1)

        print('Building model...')
        model = Sequential()

        # model.add (Embedding (self.Max_words, 512, input_length=self.Max_words))
        embedding_weights = np.zeros ((len (dict_index) + 1, 512))
        for word, index in dict_index.items ():
            embedding_weights[index, :] = word_vectors[word]
        print (embedding_weights)

        print ('input_dim: ', len (dict_index) + 1)
        model.add (Embedding (output_dim = 512, input_dim = (len (dict_index) + 1), input_length=self.Max_words, mask_zero = True, weights=[embedding_weights]))
        model.add (LSTM (512, activation='tanh', dropout=0.2, recurrent_dropout=0.2, return_sequences=True))
        # model.add (LSTM (256, activation='tanh', dropout=0.2, recurrent_dropout=0.2, return_sequences=True))
        # model.add (LSTM (128, activation='tanh', dropout=0.2, recurrent_dropout=0.2, return_sequences=True))
        # model.add (LSTM (64, activation='tanh', dropout=0.2, recurrent_dropout=0.2, return_sequences=True))
        # model.add (LSTM (32, activation='tanh', dropout=0.2, recurrent_dropout=0.2, return_sequences=True))
        model.add (LSTM (16, activation='tanh', dropout=0.2, recurrent_dropout=0.2))

        model.add(Dense(num_classes))
        model.add(Activation('softmax'))

        model.compile(loss='categorical_crossentropy',
                optimizer='adam',
                metrics=['accuracy'])
        my_model = model
        my_model.summary()

        print ('x_train: ', x_train)
        print ('x_train len: ', len (x_train))
        print ('y_train: ', y_train)
        print ('y_train len: ', len (y_train))

        print ('x_train: ', x_train[0])
        print ('x_train len: ', len (x_train[0]))
        print ('y_train: ', y_train[0])
        print ('y_train len: ', len (y_train[0]))

        my_model.fit(x_train, y_train,
                batch_size=self.Batch_size,
                epochs=self.Epochs,
                verbose=1)
                # validation_split=0.1)
        #保存权重
        my_model.save(self.Savepath)
        #测试模型/可删除
        score = my_model.evaluate(x_test, y_test,
                batch_size=self.Batch_size, verbose=1)
        print('Test score:', score[0])
        print('Test accuracy:', score[1])
        for i in range(10):
            ind = np.random.randint(0, len(x_test))
            rowx, rowy = x_test[np.array([ind])], y_test[np.array([ind])]
            print(rowx,rowy)
            preds = my_model.predict_classes(rowx, verbose=0)
            print (preds)
        print("OK")
