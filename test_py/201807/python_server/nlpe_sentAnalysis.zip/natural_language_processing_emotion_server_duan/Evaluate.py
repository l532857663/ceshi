#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os,sys
from evaluate_server.get_data import DataGeting

DG = DataGeting("Lyrical_model_base")
# with open("./utfdata/shangqiu/shangqiu1.txt","rb") as f:
with open("./utfdata/luoyang/luoyang1.txt","rb") as f:
    file_data = f.readlines()
    
i=0
for line in file_data:
    line_arr = line[:-1].split(b"\t")
    if not len(line_arr) == 2:
        continue
    else:
        res = DG.sentenceSegmentation(line_arr[0].decode())
        if line_arr[1].decode() == "敏感":
            i += 1
        if i%50 == 0:
            print(line_arr[0].decode(), line_arr[1].decode())
            print("****************",res)

print(DG.Key1,DG.Key2,i)
print("end")
